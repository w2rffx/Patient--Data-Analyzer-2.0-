# Local artifacts

The SQLite database and trained model files are created here when the pipeline runs. They are ignored by Git because they can be regenerated from the included synthetic CSV files.
