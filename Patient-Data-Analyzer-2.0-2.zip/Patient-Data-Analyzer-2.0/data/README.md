# Data folders

`raw/` contains intentionally imperfect synthetic CSV files. `processed/` contains the cleaned versions created by the pipeline. All records are fictional. The raw and processed synthetic CSV files are included in the repository so the workflow can be inspected and repeated.
