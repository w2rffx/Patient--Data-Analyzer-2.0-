# Patient Data Analyzer 2.0

**Author:** RIAN ADEL ALI SAIF AL-KMALI  
**Short name:** RIAN AL-KMALI  
**Version:** 2.0.0

A student learning project that follows a fictional healthcare dataset from imperfect raw CSV files through inspection, cleaning, SQLite storage, SQL analysis, statistics, machine learning, and reports. All included records are **synthetic**. They do not describe real patients and must not be used to make clinical decisions.

## What the project does

- Generates linked synthetic data for facilities, patients, appointments, visits, medical records, medications, and inventory transactions.
- Adds data-quality problems to the raw files, such as missing values, duplicate rows, invalid ages, unusual measurements, and invalid dates.
- Cleans the files and saves a data-quality report so the decisions can be reviewed.
- Loads cleaned tables into a local SQLite database with primary keys, foreign keys, constraints, and indexes.
- Runs SQL queries and reads selected query results into Pandas for further analysis.
- Creates charts and summary tables.
- Runs learning examples for classification, regression, clustering, anomaly detection, and weekly medicine-demand forecasting.
- Provides an optional Streamlit dashboard.

## Project workflow

```text
Synthetic raw CSV files
        |
        v
Data understanding and quality checks
        |
        v
Cleaning and validation with Pandas / NumPy
        |
        v
Clean CSV files
        |
        v
SQLite database and relational tables
        |
        v
SQL queries -> Pandas analysis
        |
        v
Statistics, charts, and machine learning
        |
        v
Evaluation, reports, and dashboard
```

## Quick start

Python 3.10 or newer is specified in `pyproject.toml`.

```bash
python -m venv .venv
# Activate the environment first.
python -m pip install -e ".[test]"
python -m patient_data_analyzer run-all
pytest -q
```

## Run individual steps

```bash
python -m patient_data_analyzer generate
python -m patient_data_analyzer clean
python -m patient_data_analyzer load-db
python -m patient_data_analyzer analyze
python -m patient_data_analyzer train
python -m patient_data_analyzer run-all
```

## Optional dashboard

```bash
python -m pip install -e ".[dashboard]"
streamlit run app.py
```

Run `run-all` first so the SQLite database and reports are available to the dashboard.

## Main folders

```text
src/patient_data_analyzer/   Python source code
sql/                         Database schema and analysis queries
data/raw/                    Imperfect synthetic raw CSV files
data/processed/              Cleaned synthetic CSV files
reports/                     Run summaries, tables, charts, and project report
notebooks/                   Guided project walkthrough
docs/                        Methodology, data dictionary, limitations, and technical notes
artifacts/                   Local database and trained models (not committed)
tests/                       Automated checks
```

## Documentation

- `reports/PROJECT_REPORT.pdf` - detailed technical report with workflow, data-quality results, SQL, modelling, dashboard, and limitations.
- `docs/TECHNICAL_DOCUMENTATION.md` - technical guide to the code, data model, workflow, and run commands.
- `docs/ENGINEERING_TOOL_DECISIONS.md` - what is actually used and which advanced tools are only future options.
- `docs/DATA_DICTIONARY.md` - synthetic table and field descriptions.
- `docs/METHODOLOGY.md` - generation, cleaning, analysis, and modelling notes.
- `docs/LIMITATIONS.md` - project boundaries and limitations.

## Main technologies actually used

Python, NumPy, Pandas, SQLite / `sqlite3`, SQL, scikit-learn, Matplotlib, Joblib, Jupyter, pytest, and optional Streamlit. The project does not claim to integrate every tool discussed in the engineering notes.

## Data and interpretation notes

The data generator uses a fixed random seed by default, so the same input settings can reproduce the same synthetic records. The generated patterns are intended for software and learning exercises. Model scores only describe how models behave on this simulated dataset; they are not evidence of clinical performance or real-world accuracy.

The medical-record fields are included for validation and descriptive-analysis exercises only. No diagnosis or treatment recommendation is produced. Records flagged by anomaly detection are unusual relative to this generated dataset, not necessarily incorrect or medically abnormal.

Do not upload real patient data to the public repository. The project has not been security-reviewed or validated for clinical deployment.
