PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS facilities (
    facility_id INTEGER PRIMARY KEY,
    facility_name TEXT NOT NULL,
    district TEXT NOT NULL,
    facility_type TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS patients (
    patient_id INTEGER PRIMARY KEY,
    age INTEGER NOT NULL CHECK (age BETWEEN 1 AND 110),
    gender TEXT NOT NULL,
    neighborhood TEXT NOT NULL,
    registration_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INTEGER PRIMARY KEY,
    patient_id INTEGER NOT NULL,
    facility_id INTEGER NOT NULL,
    scheduled_date TEXT NOT NULL,
    appointment_date TEXT NOT NULL,
    sms_received INTEGER NOT NULL CHECK (sms_received IN (0, 1)),
    previous_no_shows INTEGER NOT NULL DEFAULT 0,
    no_show TEXT NOT NULL CHECK (no_show IN ('Yes', 'No')),
    lead_days INTEGER NOT NULL CHECK (lead_days >= 0),
    appointment_hour INTEGER NOT NULL,
    appointment_weekday INTEGER NOT NULL,
    appointment_month INTEGER NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (facility_id) REFERENCES facilities(facility_id)
);

CREATE TABLE IF NOT EXISTS visits (
    visit_id INTEGER PRIMARY KEY,
    appointment_id INTEGER NOT NULL UNIQUE,
    arrival_time TEXT NOT NULL,
    service_start_time TEXT NOT NULL,
    waiting_minutes REAL NOT NULL CHECK (waiting_minutes >= 0),
    consultation_minutes REAL NOT NULL CHECK (consultation_minutes > 0),
    FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id)
);

CREATE TABLE IF NOT EXISTS medical_records (
    record_id INTEGER PRIMARY KEY,
    visit_id INTEGER NOT NULL UNIQUE,
    systolic_bp REAL NOT NULL,
    diastolic_bp REAL NOT NULL,
    heart_rate REAL NOT NULL,
    temperature_c REAL NOT NULL,
    glucose_mg_dl REAL NOT NULL,
    FOREIGN KEY (visit_id) REFERENCES visits(visit_id)
);

CREATE TABLE IF NOT EXISTS medications (
    medication_id INTEGER PRIMARY KEY,
    medication_name TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL,
    unit TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS inventory_transactions (
    transaction_id INTEGER PRIMARY KEY,
    medication_id INTEGER NOT NULL,
    facility_id INTEGER NOT NULL,
    transaction_date TEXT NOT NULL,
    transaction_type TEXT NOT NULL CHECK (transaction_type IN ('dispense', 'restock')),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    FOREIGN KEY (medication_id) REFERENCES medications(medication_id),
    FOREIGN KEY (facility_id) REFERENCES facilities(facility_id)
);

CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_patient ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_visits_appointment ON visits(appointment_id);
CREATE INDEX IF NOT EXISTS idx_inventory_date ON inventory_transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_inventory_medication ON inventory_transactions(medication_id);
