-- 1. Basic operational counts
SELECT
    (SELECT COUNT(*) FROM patients) AS patient_count,
    (SELECT COUNT(*) FROM appointments) AS appointment_count,
    (SELECT COUNT(*) FROM visits) AS visit_count,
    (SELECT COUNT(*) FROM medical_records) AS medical_record_count;

-- 2. Appointment attendance by facility
SELECT f.facility_name,
       COUNT(*) AS appointments,
       SUM(CASE WHEN a.no_show = 'Yes' THEN 1 ELSE 0 END) AS no_shows,
       ROUND(100.0 * AVG(CASE WHEN a.no_show = 'Yes' THEN 1.0 ELSE 0.0 END), 2) AS no_show_rate_percent
FROM appointments a
JOIN facilities f ON f.facility_id = a.facility_id
GROUP BY f.facility_id, f.facility_name
ORDER BY no_show_rate_percent DESC;

-- 3. Monthly appointment counts
SELECT strftime('%Y-%m', appointment_date) AS month,
       COUNT(*) AS appointment_count
FROM appointments
GROUP BY month
ORDER BY month;

-- 4. Mean waiting time by facility
SELECT f.facility_name,
       COUNT(v.visit_id) AS completed_visits,
       ROUND(AVG(v.waiting_minutes), 2) AS mean_wait_minutes
FROM visits v
JOIN appointments a ON a.appointment_id = v.appointment_id
JOIN facilities f ON f.facility_id = a.facility_id
GROUP BY f.facility_id, f.facility_name
ORDER BY mean_wait_minutes DESC;

-- 5. Dispensed quantity by medication and month
SELECT m.medication_name,
       strftime('%Y-%m', t.transaction_date) AS month,
       SUM(t.quantity) AS dispensed_units
FROM inventory_transactions t
JOIN medications m ON m.medication_id = t.medication_id
WHERE t.transaction_type = 'dispense'
GROUP BY m.medication_id, month
ORDER BY m.medication_name, month;

-- 6. Patient appointment history (a small example of JOIN + GROUP BY)
SELECT p.patient_id, p.age, p.gender,
       COUNT(a.appointment_id) AS appointment_count,
       SUM(CASE WHEN a.no_show = 'Yes' THEN 1 ELSE 0 END) AS no_show_count
FROM patients p
LEFT JOIN appointments a ON a.patient_id = p.patient_id
GROUP BY p.patient_id, p.age, p.gender
ORDER BY appointment_count DESC
LIMIT 20;
