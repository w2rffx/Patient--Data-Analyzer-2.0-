"""Optional Streamlit dashboard. Install with: pip install -e '.[dashboard]'"""
from pathlib import Path
import pandas as pd
import streamlit as st
from patient_data_analyzer.config import DB_PATH, TABLES_DIR, FIGURES_DIR
from patient_data_analyzer.database import query_to_dataframe

st.set_page_config(page_title="Patient Data Analyzer 2.0", layout="wide")
st.title("Patient Data Analyzer 2.0")
st.caption("Synthetic healthcare operations data | Learning and demonstration only")

if not DB_PATH.exists():
    st.warning("The database does not exist yet. Run `python -m patient_data_analyzer run-all` first.")
    st.stop()

kpis = query_to_dataframe(DB_PATH, """
SELECT (SELECT COUNT(*) FROM patients) AS patients,
       (SELECT COUNT(*) FROM appointments) AS appointments,
       (SELECT COUNT(*) FROM visits) AS visits,
       (SELECT ROUND(100.0 * AVG(CASE WHEN no_show='Yes' THEN 1.0 ELSE 0.0 END),2) FROM appointments) AS no_show_rate
""").iloc[0]
cols = st.columns(4)
for col, label, value in zip(cols, ["Patients", "Appointments", "Completed visits", "No-show rate"],
                             [f"{int(kpis.patients):,}", f"{int(kpis.appointments):,}", f"{int(kpis.visits):,}", f"{kpis.no_show_rate:.1f}%"]):
    col.metric(label, value)

left, right = st.columns(2)
with left:
    st.subheader("Appointments by month")
    monthly = query_to_dataframe(DB_PATH, "SELECT strftime('%Y-%m', appointment_date) month, COUNT(*) appointments FROM appointments GROUP BY month ORDER BY month")
    st.bar_chart(monthly.set_index("month"))
with right:
    st.subheader("No-show rate by facility")
    facility = query_to_dataframe(DB_PATH, "SELECT f.facility_name, ROUND(100.0*AVG(CASE WHEN a.no_show='Yes' THEN 1.0 ELSE 0.0 END),2) rate FROM appointments a JOIN facilities f USING(facility_id) GROUP BY f.facility_id")
    st.bar_chart(facility.set_index("facility_name"))

st.subheader("Waiting time by facility")
waits = query_to_dataframe(DB_PATH, "SELECT f.facility_name, ROUND(AVG(v.waiting_minutes),2) mean_wait FROM visits v JOIN appointments a USING(appointment_id) JOIN facilities f USING(facility_id) GROUP BY f.facility_id")
st.dataframe(waits, use_container_width=True, hide_index=True)

st.subheader("Data quality summary")
quality_path = TABLES_DIR / "data_quality_summary.csv"
if quality_path.exists():
    st.dataframe(pd.read_csv(quality_path), use_container_width=True, hide_index=True)
else:
    st.info("Run the full workflow to create the data-quality report.")

st.subheader("Model metrics")
metrics_path = TABLES_DIR / "model_metrics.json"
if metrics_path.exists():
    import json
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    st.json(metrics)
else:
    st.info("Run the training step to create model metrics.")
