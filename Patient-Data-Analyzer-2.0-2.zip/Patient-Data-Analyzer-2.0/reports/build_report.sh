#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
xelatex -interaction=nonstopmode -halt-on-error project_report.tex
xelatex -interaction=nonstopmode -halt-on-error project_report.tex
mv -f project_report.pdf PROJECT_REPORT.pdf
