# Pipeline Run Summary

All records in this project are synthetic.

## Database row counts

| Table | Rows |
|---|---:|
| facilities | 4 |
| patients | 2,000 |
| medications | 12 |
| appointments | 11,940 |
| visits | 8,140 |
| medical_records | 8,140 |
| inventory_transactions | 1,406 |

## Model results

| Task | Main test metric | Value |
|---|---|---:|
| No-show classification | F1 | 0.695 |
| Waiting-time regression | MAE (minutes) | 5.79 |
| Weekly medicine forecasting | MAE (units) | 7.70 |

Clustering and anomaly detection outputs are available in `reports/tables/`. These are exploratory outputs, not clinical conclusions.
