# Data Dictionary

All included data are synthetic and were generated for this project. Dates refer to a simulated 2025 period.

| File / table | Important fields | Description |
|---|---|---|
| facilities | facility_id, facility_name, district, facility_type | Four fictional primary-care facilities. |
| patients | patient_id, age, gender, neighborhood, registration_date | Synthetic patient profiles. |
| appointments | appointment_id, patient_id, facility_id, scheduled_date, appointment_date, sms_received, previous_no_shows, no_show | Booking and attendance records. |
| visits | visit_id, appointment_id, arrival_time, service_start_time, waiting_minutes, consultation_minutes | Completed visit operations. |
| medical_records | record_id, visit_id, systolic_bp, diastolic_bp, heart_rate, temperature_c, glucose_mg_dl | Simulated measurements for data-validation exercises only. |
| medications | medication_id, medication_name, category, unit | Fictional clinic medicine catalogue. |
| inventory_transactions | transaction_id, medication_id, facility_id, transaction_date, transaction_type, quantity | Simulated medicine dispensing and restocking movements. |

## Notes

- `no_show` is the target for the appointment classification example. `Yes` means the synthetic appointment was missed.
- `waiting_minutes` is the regression target. Input features are taken from the appointment and patient profile; visit-time fields are not used as model inputs.
- Medicine forecasting uses past weekly dispensing quantities (lag features) to estimate the next week's quantity.
- Missing values, duplicate rows, and invalid values are intentionally injected into raw files. See `reports/tables/data_quality_summary.csv` after running the pipeline.
