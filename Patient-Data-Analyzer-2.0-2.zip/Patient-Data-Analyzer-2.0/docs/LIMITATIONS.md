# Limitations

1. All data are generated. They are not a substitute for real clinic records or field research.
2. The simulated relationships were designed for learning. Performance scores may change when the generator settings change.
3. A high score on simulated data does not show that a model will work in a real clinic.
4. The dataset does not represent the population, services, or disease patterns of Taiz or Yemen.
5. Medical measurements are included only to practice validation and descriptive analysis. The project does not diagnose or recommend treatment.
6. An anomaly flag marks a record as unusual relative to the generated data. It does not prove that the record is wrong.
7. The forecasting exercise predicts one week ahead using lagged values. It is not an inventory ordering system.
8. The project is an educational prototype. It has not been security-reviewed or validated for clinical deployment.
