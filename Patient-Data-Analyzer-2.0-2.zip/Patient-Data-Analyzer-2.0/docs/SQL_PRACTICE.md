# SQL Practice in This Project

The project uses SQLite through Python's built-in `sqlite3` module. The main examples are in `sql/analysis_queries.sql`.

You can practice:

- `CREATE TABLE` and constraints in `schema.sql`.
- `INSERT` through Pandas `to_sql` in the database loader.
- `SELECT` and `WHERE` for filtering rows.
- `JOIN` to connect appointments, patients, facilities, and visits.
- `GROUP BY` and aggregate functions for operational summaries.
- `CASE WHEN` for counting missed appointments.
- `strftime` for grouping dates by month.
- Indexes for commonly used date and foreign-key columns.

A small query example:

```sql
SELECT f.facility_name,
       COUNT(*) AS appointment_count,
       ROUND(100.0 * AVG(CASE WHEN a.no_show = 'Yes' THEN 1.0 ELSE 0.0 END), 2) AS no_show_rate
FROM appointments AS a
JOIN facilities AS f ON f.facility_id = a.facility_id
GROUP BY f.facility_id, f.facility_name;
```

Python reads query results into Pandas with `pd.read_sql_query`, so SQL and Pandas work together rather than competing with each other.
