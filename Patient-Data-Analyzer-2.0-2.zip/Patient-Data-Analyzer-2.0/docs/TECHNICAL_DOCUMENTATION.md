# Technical Documentation

**Project:** Patient Data Analyzer 2.0  
**Author:** RIAN ADEL ALI SAIF AL-KMALI  
**Short name:** RIAN AL-KMALI  
**Version:** 2.0.0

## 1. What the project does

Patient Data Analyzer 2.0 is a student learning project built around a fictional primary-healthcare network. It follows a set of connected records from intentionally imperfect CSV files through data inspection, cleaning, validation, SQLite storage, SQL queries, statistical analysis, machine-learning experiments, and reporting.

Every record included in the repository is synthetic. The project is not connected to a real clinic, does not describe the population of Yemen or Taiz, and must not be used to diagnose patients, recommend treatment, or make operational healthcare decisions.

## 2. Main workflow

```text
Synthetic raw CSV files
        |
        v
Data understanding and quality checks
        |
        v
Cleaning and validation with Pandas / NumPy
        |
        v
Clean CSV files + quality summary
        |
        v
SQLite database (7 related tables)
        |
        v
SQL queries
        |
        v
Pandas analysis and descriptive statistics
        |
        v
Machine-learning experiments
        |
        v
Evaluation tables, figures, reports, and dashboard
```

The raw files are not overwritten. The cleaned files are saved separately, then loaded into SQLite. SQL is used for relational queries; Pandas receives selected query results for additional analysis and charts.

## 3. Repository map

```text
Patient-Data-Analyzer-2.0/
├── app.py
├── pyproject.toml
├── requirements.txt
├── README.md
├── data/
│   ├── raw/                 # Imperfect synthetic source files
│   └── processed/           # Cleaned synthetic files
├── src/patient_data_analyzer/
│   ├── data_generation.py   # Creates connected synthetic tables
│   ├── cleaning.py          # Inspects and cleans each table
│   ├── database.py          # SQLite setup, loading, and queries
│   ├── analysis.py          # SQL summaries and descriptive charts
│   ├── modeling.py          # Five machine-learning exercises
│   ├── pipeline.py          # Connects the workflow steps
│   ├── config.py            # Project paths and random seed
│   └── __main__.py          # Command-line entry point
├── sql/
│   ├── schema.sql           # Tables, keys, constraints, and indexes
│   └── analysis_queries.sql # Example analytical queries
├── notebooks/
│   └── 01_end_to_end_walkthrough.ipynb
├── docs/
│   ├── DATA_DICTIONARY.md
│   ├── METHODOLOGY.md
│   ├── LIMITATIONS.md
│   ├── SQL_PRACTICE.md
│   ├── PROJECT_STRUCTURE.md
│   ├── ENGINEERING_TOOL_DECISIONS.md
│   └── TECHNICAL_DOCUMENTATION.md
├── reports/
│   ├── project_report.tex
│   ├── PROJECT_REPORT.pdf
│   ├── RUN_SUMMARY.md
│   ├── tables/
│   └── figures/
├── tests/
└── artifacts/               # Local database and model files; not committed
```

## 4. Data model

The relational database contains seven tables:

| Table | Main key | Main relationship |
|---|---|---|
| `facilities` | `facility_id` | Parent of appointments and inventory transactions |
| `patients` | `patient_id` | Parent of appointments |
| `appointments` | `appointment_id` | References a patient and a facility; parent of visits |
| `visits` | `visit_id` | References an appointment; parent of medical records |
| `medical_records` | `record_id` | References a visit |
| `medications` | `medication_id` | Parent of inventory transactions |
| `inventory_transactions` | `transaction_id` | References a medication and a facility |

The SQL schema uses primary keys, foreign keys, selected `CHECK` constraints, uniqueness rules, and indexes. Foreign-key enforcement is enabled on each Python SQLite connection.

## 5. Data generation and cleaning

The generator uses a fixed seed by default so that the same configuration can produce repeatable records. It creates a fictional year from January through December 2025. The raw CSV files deliberately contain missing values, duplicate identifiers, invalid dates, and out-of-range measurements or durations.

The current run contains 31,970 raw rows across seven datasets. Cleaning leaves 31,642 rows. The cleaning summary records 328 removed rows, including 161 duplicate identifiers. The number of missing cells recorded by the report falls from 2,383 to zero after the current cleaning rules are applied.

These are rules for this simulation, not clinical standards. For example, the age and measurement ranges in the cleaning code are exercise-specific boundaries. A real dataset would need a source-specific data dictionary and review by appropriate domain experts.

## 6. Machine-learning tasks

| Task | Current method | Target / purpose |
|---|---|---|
| No-show classification | Logistic Regression | Predict the synthetic `no_show` label |
| Waiting-time regression | Random Forest Regressor | Estimate simulated waiting minutes |
| Behaviour clustering | K-Means | Explore groups based on appointment behaviour |
| Operational anomaly detection | Isolation Forest | Flag unusual operational records for review |
| Weekly medicine forecasting | Random Forest Regressor with lag features | Estimate next-week dispensed quantities |

The supervised appointment and waiting-time tasks use chronological 80/20 train/test splits. Preprocessing for the classification model is kept inside a scikit-learn Pipeline. Identifiers are not used as predictive features in the no-show model. Waiting-time inputs exclude arrival and service-start fields that would not be known at booking time.

## 7. Current reproducible results

Results from the latest complete run in this repository:

| Task | Result | Interpretation |
|---|---:|---|
| No-show classification | F1 = 0.695; ROC-AUC = 0.811 | Measures performance only on the generated labels |
| Waiting-time regression | MAE = 5.79 min; R-squared = 0.108 | Current booking features explain little variation |
| K-Means clustering | Silhouette = 0.199 | Weak group separation; exploratory only |
| Isolation Forest | 245 of 8,140 visits (3.01%) flagged | Unusual relative to this simulation, not necessarily erroneous |
| Weekly medicine forecasting | MAE = 7.70 units; R-squared = 0.747 | Based on a short simulated time series |

The scores are not evidence of performance on real clinic data. The generator itself creates some of the patterns that the models learn. The low waiting-time R-squared and modest clustering silhouette are reported rather than hidden.

## 8. Run the project

Python 3.10 or newer is specified in `pyproject.toml`.

```bash
python -m venv .venv
# Activate the environment first.
python -m pip install -e ".[test]"
python -m patient_data_analyzer run-all
pytest -q
```

Run individual stages when needed:

```bash
python -m patient_data_analyzer generate
python -m patient_data_analyzer clean
python -m patient_data_analyzer load-db
python -m patient_data_analyzer analyze
python -m patient_data_analyzer train
```

Optional dashboard:

```bash
python -m pip install -e ".[dashboard]"
streamlit run app.py
```

The `artifacts/` folder is generated locally. It contains the SQLite database and saved model files. They can be rebuilt from the included synthetic data and are ignored by Git.

## 9. Verification status

The full pipeline was run from the source tree using `PYTHONPATH=src`; it completed and produced the table counts and metrics above. The current automated test suite contains two smoke/integration tests. Both passed in the verification run. These tests check a small end-to-end data/database path and the cleaned age range; they do not constitute full test coverage.

The Streamlit application source is included and a static dashboard preview is included in `reports/figures/`. The interactive app was not launched during this verification run because the optional Streamlit dependency was not installed in that execution environment.

## 10. Security and privacy boundary

Only synthetic data belong in the public repository. Never add real patient names, phone numbers, national identifiers, addresses, medical records, or other identifying health information without a clear legal basis, institutional permission, and an approved privacy and security process. The current project has no authentication, access control, encryption-at-rest design, audit logging for real users, security review, or clinical validation.

## 11. Engineering decisions

The project deliberately uses a modest stack that can be understood and maintained by one student: Python, NumPy, Pandas, SQLite through Python's built-in `sqlite3`, SQL, scikit-learn, Matplotlib, pytest, Jupyter, and an optional Streamlit interface.

Additional tools such as Polars, DuckDB, SQLAlchemy, Apache Arrow, DVC, workflow orchestrators, Docker, Great Expectations, Pydantic, MLflow, Optuna, Yellowbrick, Ruff, Quarto, Pandoc, and Sphinx are discussed in `ENGINEERING_TOOL_DECISIONS.md`. They are not claimed as integrated features of the current code. Several are alternatives or solve problems the project does not yet have. Adding every tool would increase installation and maintenance work without automatically improving the project.
