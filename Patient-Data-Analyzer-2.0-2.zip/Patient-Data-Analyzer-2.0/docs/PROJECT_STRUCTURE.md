# Project Structure

```text
Patient-Data-Analyzer-2.0/
├── app.py
├── pyproject.toml
├── README.md
├── requirements.txt
├── data/
│   ├── raw/
│   └── processed/
├── src/patient_data_analyzer/
│   ├── data_generation.py
│   ├── cleaning.py
│   ├── database.py
│   ├── analysis.py
│   ├── modeling.py
│   ├── pipeline.py
│   ├── config.py
│   └── __main__.py
├── sql/
│   ├── schema.sql
│   └── analysis_queries.sql
├── notebooks/
├── reports/
├── artifacts/
└── tests/
```

The package is intentionally split into a small number of files. Each file has one main responsibility, and the command-line entry point connects the steps in the correct order.
