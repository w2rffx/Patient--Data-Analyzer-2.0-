# Engineering Tool Decisions

**Author:** RIAN ADEL ALI SAIF AL-KMALI  
**Project:** Patient Data Analyzer 2.0

This file separates what is actually used from what may become useful later. A dependency is not considered integrated just because it appears in a technology list. It is integrated only when the repository contains working code/configuration and the workflow uses it.

## Current implementation

| Tool | Status | Where it is used |
|---|---|---|
| Python | Used | Main programming language and pipeline |
| NumPy | Used | Synthetic numerical generation and array operations |
| Pandas | Used | CSV inspection, cleaning, feature preparation, and analysis |
| SQLite / `sqlite3` | Used | Local relational database and database access |
| SQL | Used | Schema, constraints, joins, grouping, and summaries |
| scikit-learn | Used | Classification, regression, clustering, anomaly detection, and forecasting |
| Matplotlib | Used | Saved charts and report figures |
| Joblib | Used | Saving trained model objects locally |
| Jupyter | Included | Guided notebook workflow |
| pytest | Used | Two automated smoke/integration tests currently pass |
| Streamlit | Optional | Dashboard code is included in `app.py`; install the optional extra to run it |
| XeLaTeX | Used for this report | Compiles `reports/project_report.tex` to PDF |

## Requested tools reviewed for later use

| Tool | Current status | Why it is not part of the current runtime |
|---|---|---|
| LuaLaTeX | Alternative, not used | XeLaTeX is the selected engine for the current PDF source. Both are TeX engines; using both would not add value here. |
| Quarto | Not integrated | Useful for documents that execute Python code while rendering. The existing notebook and report source are enough for the current project. |
| Pandoc | Not integrated | Useful for converting Markdown, LaTeX, DOCX, and other formats. The report is written directly in LaTeX, so a conversion layer is not needed. |
| Sphinx | Not integrated | Useful for searchable API documentation generated from docstrings. The package is still small, and the current Markdown documentation is easier to maintain. |
| Polars | Not integrated | A high-performance DataFrame library. The present datasets are small enough for Pandas; adding a second DataFrame API would create extra learning and maintenance work. |
| DuckDB | Not integrated | Useful for analytical SQL over large files and columnar data. SQLite is the selected relational database for this project and supports the SQL learning objectives. |
| SQLAlchemy | Not integrated | Useful for a database abstraction layer or ORM. The project uses Python's built-in `sqlite3` so the SQL statements and relationships remain visible and easy to learn. |
| Apache Arrow / PyArrow | Not integrated | Useful for efficient columnar interchange between data tools. Current CSV and SQLite volumes do not justify another data interchange layer. |
| DVC | Not integrated | Useful when datasets, model artifacts, and pipeline versions become too large or change too often for ordinary Git. Current synthetic CSV files are small and are intentionally visible in the repository. |
| Apache Airflow | Not integrated | Designed for scheduled and monitored workflows with dependencies, retries, and operational management. The current project is a local, manually started pipeline. |
| Prefect | Not integrated | A Python workflow orchestration option with state and retry features. It is an alternative to heavier orchestration for future recurring jobs, not a required layer for one local run. |
| GNU Make | Not integrated | Could provide short command aliases, but the project already has a command-line entry point with named stages. |
| Docker | Not integrated | Useful for packaging a consistent runtime or deploying services. The current goal is to run and understand the Python project locally or in a notebook. |
| Great Expectations | Not integrated | Useful for declarative data-quality suites and validation documentation. Current checks are written directly in the cleaning functions and smoke tests. |
| Pydantic | Not integrated | Useful for validating structured configuration and external input. Current configuration is a small set of local paths and a random seed. |
| MLflow | Not integrated | Useful for tracking many experiments, parameters, metrics, and artifacts. Current results are saved as JSON, CSV, and Joblib files. |
| Optuna | Not integrated | Useful for systematic hyperparameter search. The next sensible step is to establish baseline comparisons before tuning models. |
| Yellowbrick | Not integrated | Useful for model- and feature-diagnostic visualizations. Matplotlib already covers the current charts; extra visual tooling can wait until a specific diagnostic need appears. |
| Ruff | Not integrated yet | A useful linter and formatter that can be added when code-quality checks are expanded. It has not been configured or run in the current repository. |

## A sensible order for future additions

1. **Ruff and stronger pytest coverage:** low-friction code checks and tests before adding infrastructure.
2. **Pydantic or Great Expectations:** add only when configuration and data contracts become larger than the current explicit checks.
3. **MLflow:** add when comparing multiple model versions or hyperparameter experiments becomes a real need.
4. **Optuna:** consider after baseline models and a stable evaluation protocol exist.
5. **DVC:** consider if raw/processed data and model artifacts outgrow ordinary Git storage.
6. **Quarto:** consider if the project needs executable research reports that regenerate tables and plots from code.
7. **Prefect or Airflow:** consider only if workflows need scheduling, retries, monitoring, or multiple recurring jobs. Choose one; do not install both by default.
8. **Polars, DuckDB, Arrow, or SQLAlchemy:** evaluate only after performance, file-format, or database-abstraction needs are measured.
9. **Docker and Sphinx:** consider when repeatable deployment environments or a larger public Python API become useful.

The goal is not to collect technology names. The goal is to make each tool solve a problem that the project actually has.
