# Methodology Notes

## 1. Data generation

The generator creates related tables using a fixed random seed. Appointment attendance has a simulated relationship with booking lead time, reminder receipt, and earlier missed appointments. Waiting time is influenced by the simulated facility and appointment time. Medicine demand varies by item and week. Random variation is included so the generated relationships are not perfectly predictable.

## 2. Cleaning

The cleaning stage removes duplicate primary identifiers, parses dates, checks valid ranges, removes rows that cannot be linked to a valid parent record, and imputes selected missing values. Every cleaning rule is implemented in `src/patient_data_analyzer/cleaning.py`. The original raw CSV files are not overwritten.

## 3. Database

SQLite stores the cleaned tables. The schema uses primary keys, foreign keys, CHECK constraints, and indexes. The loader clears tables in child-first order before reloading, so the database can be rebuilt consistently.

## 4. Analysis

SQL is used for joins and grouped summaries. Pandas reads query results into DataFrames for descriptive statistics and charts.

## 5. Machine learning

- No-show classification: logistic regression with a chronological 80/20 split.
- Waiting-time regression: random forest with a chronological 80/20 split.
- Patient behaviour clustering: K-Means on appointment counts, no-show rate, average lead time, and age.
- Operational anomaly detection: Isolation Forest on visit operations.
- Medicine-demand forecasting: random forest using lag features and a chronological split.

The supervised preprocessing steps are placed inside scikit-learn Pipelines. The test period is kept after the training period. This is a learning design, not a fully validated forecasting or healthcare model.
