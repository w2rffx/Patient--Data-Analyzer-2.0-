"""Clean generated raw CSV files and record what changed."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd


def _read(folder: Path, name: str) -> pd.DataFrame:
    path = Path(folder) / f"{name}.csv"
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}. Run the generate step first.")
    return pd.read_csv(path)


def _save(frame: pd.DataFrame, folder: Path, name: str) -> None:
    Path(folder).mkdir(parents=True, exist_ok=True)
    frame.to_csv(Path(folder) / f"{name}.csv", index=False)


def _basic_counts(name: str, raw: pd.DataFrame, clean: pd.DataFrame, duplicates_removed: int) -> dict:
    return {
        "dataset": name,
        "raw_rows": int(len(raw)),
        "clean_rows": int(len(clean)),
        "rows_removed": int(len(raw) - len(clean)),
        "duplicates_removed": int(duplicates_removed),
        "missing_cells_before": int(raw.isna().sum().sum()),
        "missing_cells_after": int(clean.isna().sum().sum()),
    }


def clean_all(raw_dir: Path, processed_dir: Path, report_dir: Path) -> pd.DataFrame:
    raw_dir, processed_dir, report_dir = Path(raw_dir), Path(processed_dir), Path(report_dir)
    processed_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)
    quality_rows = []

    facilities = _read(raw_dir, "facilities")
    facilities = facilities.drop_duplicates("facility_id").copy()
    quality_rows.append(_basic_counts("facilities", _read(raw_dir, "facilities"), facilities, 0))
    _save(facilities, processed_dir, "facilities")

    medications_raw = _read(raw_dir, "medications")
    medications = medications_raw.drop_duplicates("medication_id").copy()
    quality_rows.append(_basic_counts("medications", medications_raw, medications, len(medications_raw)-len(medications)))
    _save(medications, processed_dir, "medications")

    patients_raw = _read(raw_dir, "patients")
    patients = patients_raw.drop_duplicates("patient_id", keep="first").copy()
    patients["age"] = pd.to_numeric(patients["age"], errors="coerce")
    patients.loc[~patients["age"].between(1, 110), "age"] = np.nan
    patients["age"] = patients["age"].fillna(patients["age"].median()).round().astype(int)
    for col in ("gender", "neighborhood"):
        patients[col] = patients[col].fillna("Unknown").astype(str).str.strip()
        patients.loc[patients[col].isin(["", "nan", "None"]), col] = "Unknown"
    patients["registration_date"] = pd.to_datetime(patients["registration_date"], errors="coerce")
    patients = patients.dropna(subset=["registration_date"])
    patients["registration_date"] = patients["registration_date"].dt.strftime("%Y-%m-%d")
    quality_rows.append(_basic_counts("patients", patients_raw, patients, len(patients_raw.drop_duplicates("patient_id")) and len(patients_raw)-len(patients_raw.drop_duplicates("patient_id"))))
    _save(patients, processed_dir, "patients")

    appointments_raw = _read(raw_dir, "appointments")
    appointments = appointments_raw.drop_duplicates("appointment_id", keep="first").copy()
    appointments["scheduled_date"] = pd.to_datetime(appointments["scheduled_date"], errors="coerce")
    appointments["appointment_date"] = pd.to_datetime(appointments["appointment_date"], errors="coerce")
    appointments["sms_received"] = pd.to_numeric(appointments["sms_received"], errors="coerce")
    appointments["previous_no_shows"] = pd.to_numeric(appointments["previous_no_shows"], errors="coerce")
    appointments = appointments.dropna(subset=["scheduled_date", "appointment_date", "no_show"])
    appointments = appointments.loc[appointments["appointment_date"] >= appointments["scheduled_date"]].copy()
    appointments["sms_received"] = appointments["sms_received"].fillna(0).clip(0, 1).astype(int)
    appointments["previous_no_shows"] = appointments["previous_no_shows"].fillna(0).clip(lower=0).astype(int)
    appointments["no_show"] = appointments["no_show"].astype(str).str.strip().str.title()
    appointments = appointments.loc[appointments["no_show"].isin(["Yes", "No"])].copy()
    valid_patient_ids = set(patients["patient_id"].astype(int))
    valid_facility_ids = set(facilities["facility_id"].astype(int))
    appointments = appointments.loc[
        appointments["patient_id"].isin(valid_patient_ids) & appointments["facility_id"].isin(valid_facility_ids)
    ].copy()
    appointments["lead_days"] = (appointments["appointment_date"].dt.normalize() - appointments["scheduled_date"].dt.normalize()).dt.days
    appointments["appointment_hour"] = appointments["appointment_date"].dt.hour
    appointments["appointment_weekday"] = appointments["appointment_date"].dt.dayofweek
    appointments["appointment_month"] = appointments["appointment_date"].dt.month
    appointments["scheduled_date"] = appointments["scheduled_date"].dt.strftime("%Y-%m-%d %H:%M:%S")
    appointments["appointment_date"] = appointments["appointment_date"].dt.strftime("%Y-%m-%d %H:%M:%S")
    dup_count = len(appointments_raw) - len(appointments_raw.drop_duplicates("appointment_id"))
    quality_rows.append(_basic_counts("appointments", appointments_raw, appointments, dup_count))
    _save(appointments, processed_dir, "appointments")

    visits_raw = _read(raw_dir, "visits")
    visits = visits_raw.drop_duplicates("visit_id", keep="first").copy()
    visits["arrival_time"] = pd.to_datetime(visits["arrival_time"], errors="coerce")
    visits["service_start_time"] = pd.to_datetime(visits["service_start_time"], errors="coerce")
    visits["waiting_minutes"] = pd.to_numeric(visits["waiting_minutes"], errors="coerce")
    visits["consultation_minutes"] = pd.to_numeric(visits["consultation_minutes"], errors="coerce")
    visits.loc[~visits["waiting_minutes"].between(0, 180), "waiting_minutes"] = np.nan
    visits.loc[~visits["consultation_minutes"].between(1, 120), "consultation_minutes"] = np.nan
    valid_appt_ids = set(appointments["appointment_id"].astype(int))
    visits = visits.loc[visits["appointment_id"].isin(valid_appt_ids)].copy()
    visits = visits.dropna(subset=["arrival_time", "service_start_time"])
    if visits["waiting_minutes"].isna().all():
        visits["waiting_minutes"] = 0.0
    else:
        visits["waiting_minutes"] = visits["waiting_minutes"].fillna(visits["waiting_minutes"].median())
    visits["consultation_minutes"] = visits["consultation_minutes"].fillna(visits["consultation_minutes"].median())
    visits["arrival_time"] = visits["arrival_time"].dt.strftime("%Y-%m-%d %H:%M:%S")
    visits["service_start_time"] = visits["service_start_time"].dt.strftime("%Y-%m-%d %H:%M:%S")
    dup_count = len(visits_raw) - len(visits_raw.drop_duplicates("visit_id"))
    quality_rows.append(_basic_counts("visits", visits_raw, visits, dup_count))
    _save(visits, processed_dir, "visits")

    records_raw = _read(raw_dir, "medical_records")
    records = records_raw.drop_duplicates("record_id", keep="first").copy()
    ranges = {
        "systolic_bp": (70, 240), "diastolic_bp": (40, 150),
        "heart_rate": (35, 180), "temperature_c": (34, 42),
        "glucose_mg_dl": (40, 500),
    }
    for col, (low, high) in ranges.items():
        records[col] = pd.to_numeric(records[col], errors="coerce")
        records.loc[~records[col].between(low, high), col] = np.nan
        records[col] = records[col].fillna(records[col].median())
    valid_visit_ids = set(visits["visit_id"].astype(int))
    records = records.loc[records["visit_id"].isin(valid_visit_ids)].copy()
    dup_count = len(records_raw) - len(records_raw.drop_duplicates("record_id"))
    quality_rows.append(_basic_counts("medical_records", records_raw, records, dup_count))
    _save(records, processed_dir, "medical_records")

    inventory_raw = _read(raw_dir, "inventory_transactions")
    inventory = inventory_raw.drop_duplicates("transaction_id", keep="first").copy()
    inventory["transaction_date"] = pd.to_datetime(inventory["transaction_date"], errors="coerce")
    inventory["quantity"] = pd.to_numeric(inventory["quantity"], errors="coerce")
    inventory = inventory.dropna(subset=["transaction_date", "quantity"])
    inventory = inventory.loc[inventory["quantity"] > 0].copy()
    inventory["quantity"] = inventory["quantity"].round().astype(int)
    inventory["transaction_type"] = inventory["transaction_type"].astype(str).str.lower().str.strip()
    inventory = inventory.loc[inventory["transaction_type"].isin(["dispense", "restock"])].copy()
    inventory = inventory.loc[
        inventory["medication_id"].isin(set(medications["medication_id"].astype(int)))
        & inventory["facility_id"].isin(valid_facility_ids)
    ].copy()
    inventory["transaction_date"] = inventory["transaction_date"].dt.strftime("%Y-%m-%d")
    dup_count = len(inventory_raw) - len(inventory_raw.drop_duplicates("transaction_id"))
    quality_rows.append(_basic_counts("inventory_transactions", inventory_raw, inventory, dup_count))
    _save(inventory, processed_dir, "inventory_transactions")

    report = pd.DataFrame(quality_rows)
    report.to_csv(report_dir / "data_quality_summary.csv", index=False)
    return report
