"""SQL and Pandas summaries plus exploratory charts."""
from __future__ import annotations
from pathlib import Path
import sqlite3
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .database import connect, query_to_dataframe


def run_analysis(db_path: Path, figures_dir: Path, tables_dir: Path) -> dict[str, pd.DataFrame]:
    figures_dir, tables_dir = Path(figures_dir), Path(tables_dir)
    figures_dir.mkdir(parents=True, exist_ok=True)
    tables_dir.mkdir(parents=True, exist_ok=True)

    overview = query_to_dataframe(db_path, """
        SELECT
          (SELECT COUNT(*) FROM patients) AS patients,
          (SELECT COUNT(*) FROM appointments) AS appointments,
          (SELECT COUNT(*) FROM visits) AS visits,
          (SELECT COUNT(*) FROM medical_records) AS medical_records,
          (SELECT COUNT(*) FROM inventory_transactions) AS inventory_transactions
    """)
    by_facility = query_to_dataframe(db_path, """
        SELECT f.facility_name, COUNT(*) AS appointments,
          SUM(CASE WHEN a.no_show='Yes' THEN 1 ELSE 0 END) AS no_shows,
          ROUND(100.0 * AVG(CASE WHEN a.no_show='Yes' THEN 1.0 ELSE 0.0 END), 2) AS no_show_rate_percent
        FROM appointments a JOIN facilities f USING(facility_id)
        GROUP BY f.facility_id, f.facility_name ORDER BY no_show_rate_percent DESC
    """)
    monthly = query_to_dataframe(db_path, """
        SELECT strftime('%Y-%m', appointment_date) AS month, COUNT(*) AS appointments,
          ROUND(100.0 * AVG(CASE WHEN no_show='Yes' THEN 1.0 ELSE 0.0 END), 2) AS no_show_rate_percent
        FROM appointments GROUP BY month ORDER BY month
    """)
    waits = query_to_dataframe(db_path, """
        SELECT f.facility_name, COUNT(*) AS visits, ROUND(AVG(v.waiting_minutes),2) AS mean_wait_minutes
        FROM visits v JOIN appointments a USING(appointment_id)
        JOIN facilities f USING(facility_id)
        GROUP BY f.facility_id, f.facility_name ORDER BY mean_wait_minutes DESC
    """)
    medicine = query_to_dataframe(db_path, """
        SELECT m.medication_name, SUM(t.quantity) AS dispensed_units
        FROM inventory_transactions t JOIN medications m USING(medication_id)
        WHERE t.transaction_type='dispense'
        GROUP BY m.medication_id, m.medication_name ORDER BY dispensed_units DESC
    """)
    patient_summary = query_to_dataframe(db_path, """
        SELECT p.patient_id, p.age, p.gender, COUNT(a.appointment_id) AS appointment_count,
          AVG(CASE WHEN a.no_show='Yes' THEN 1.0 ELSE 0.0 END) AS no_show_rate,
          AVG(a.lead_days) AS mean_lead_days
        FROM patients p LEFT JOIN appointments a USING(patient_id)
        GROUP BY p.patient_id, p.age, p.gender
    """)
    wait_detail = query_to_dataframe(db_path, """
        SELECT v.waiting_minutes, v.consultation_minutes, a.appointment_date,
               a.appointment_hour, a.appointment_weekday, a.facility_id, p.age
        FROM visits v JOIN appointments a USING(appointment_id)
        JOIN patients p USING(patient_id)
    """)

    outputs = {
        "operational_overview": overview,
        "appointments_by_facility": by_facility,
        "monthly_appointments": monthly,
        "waiting_time_by_facility": waits,
        "medicine_dispensing_summary": medicine,
        "patient_summary": patient_summary,
    }
    for name, frame in outputs.items():
        frame.to_csv(tables_dir / f"{name}.csv", index=False)

    # Chart 1: monthly activity.
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ax.bar(monthly["month"], monthly["appointments"])
    ax.set_title("Appointments by Month")
    ax.set_xlabel("Month")
    ax.set_ylabel("Number of appointments")
    ax.tick_params(axis="x", rotation=45)
    fig.tight_layout()
    fig.savefig(figures_dir / "appointments_by_month.png", dpi=180)
    plt.close(fig)

    # Chart 2: no-show rate across facilities.
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.barh(by_facility["facility_name"], by_facility["no_show_rate_percent"])
    ax.set_title("Appointment No-Show Rate by Facility")
    ax.set_xlabel("No-show rate (%)")
    fig.tight_layout()
    fig.savefig(figures_dir / "no_show_by_facility.png", dpi=180)
    plt.close(fig)

    # Chart 3: waiting time distribution.
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.hist(wait_detail["waiting_minutes"], bins=25, edgecolor="black")
    ax.set_title("Distribution of Patient Waiting Times")
    ax.set_xlabel("Waiting time (minutes)")
    ax.set_ylabel("Number of visits")
    fig.tight_layout()
    fig.savefig(figures_dir / "waiting_time_distribution.png", dpi=180)
    plt.close(fig)

    # Chart 4: most frequently dispensed medicine units.
    fig, ax = plt.subplots(figsize=(9, 5.2))
    top = medicine.head(10).sort_values("dispensed_units")
    ax.barh(top["medication_name"], top["dispensed_units"])
    ax.set_title("Dispensed Units by Medication (Top 10)")
    ax.set_xlabel("Units dispensed")
    fig.tight_layout()
    fig.savefig(figures_dir / "medicine_demand.png", dpi=180)
    plt.close(fig)

    # Chart 5: simple patient age distribution.
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.hist(patient_summary["age"], bins=20, edgecolor="black")
    ax.set_title("Synthetic Patient Age Distribution")
    ax.set_xlabel("Age")
    ax.set_ylabel("Number of patients")
    fig.tight_layout()
    fig.savefig(figures_dir / "patient_age_distribution.png", dpi=180)
    plt.close(fig)

    # Chart 6: illustrative dashboard-style overview using actual pipeline summaries.
    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    axes[0, 0].bar(monthly["month"], monthly["appointments"])
    axes[0, 0].set_title("Appointments per Month")
    axes[0, 0].tick_params(axis="x", rotation=45)
    axes[0, 1].barh(by_facility["facility_name"], by_facility["no_show_rate_percent"])
    axes[0, 1].set_title("No-Show Rate by Facility (%)")
    axes[1, 0].hist(wait_detail["waiting_minutes"], bins=20, edgecolor="black")
    axes[1, 0].set_title("Waiting Time Distribution")
    axes[1, 1].barh(top["medication_name"], top["dispensed_units"])
    axes[1, 1].set_title("Top Dispensed Medicines")
    fig.suptitle("Patient Data Analyzer - Dashboard Preview", fontsize=15)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(figures_dir / "dashboard_preview.png", dpi=180)
    plt.close(fig)

    return outputs
