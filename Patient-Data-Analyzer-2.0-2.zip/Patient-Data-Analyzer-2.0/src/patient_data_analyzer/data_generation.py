"""Create linked synthetic healthcare operations data with intentional quality issues."""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

DEFAULT_SEED = 42


def _write(df: pd.DataFrame, folder: Path, name: str) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    df.to_csv(folder / f"{name}.csv", index=False)


def generate_all(output_dir: Path, seed: int = DEFAULT_SEED,
                 n_patients: int = 2000, n_appointments: int = 12000) -> dict[str, int]:
    """Generate raw CSV files. All generated people and records are fictional."""
    rng = np.random.default_rng(seed)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    facilities = pd.DataFrame({
        "facility_id": [1, 2, 3, 4],
        "facility_name": ["Al-Nour Primary Center", "Al-Salam Clinic", "Al-Hayat Health Unit", "Al-Amal Center"],
        "district": ["Central", "East", "North", "West"],
        "facility_type": ["Primary Center", "Clinic", "Health Unit", "Primary Center"],
    })

    patient_ids = np.arange(100001, 100001 + n_patients)
    patients = pd.DataFrame({
        "patient_id": patient_ids,
        "age": rng.integers(1, 91, n_patients),
        "gender": rng.choice(["Female", "Male"], n_patients, p=[0.53, 0.47]),
        "neighborhood": rng.choice(["Central", "Al-Qahira", "Al-Mudhaffar", "Salh", "Bir Basha", "Other"], n_patients),
        "registration_date": pd.to_datetime("2024-01-01") + pd.to_timedelta(rng.integers(0, 730, n_patients), unit="D"),
    })
    patients["registration_date"] = patients["registration_date"].dt.strftime("%Y-%m-%d")

    appointment_dates = pd.to_datetime("2025-01-01") + pd.to_timedelta(rng.integers(0, 365, n_appointments), unit="D")
    hours = rng.choice(np.arange(8, 16), n_appointments, p=[0.08, 0.13, 0.17, 0.18, 0.16, 0.13, 0.09, 0.06])
    mins = rng.choice([0, 15, 30, 45], n_appointments)
    appointment_dates = appointment_dates + pd.to_timedelta(hours, unit="h") + pd.to_timedelta(mins, unit="m")
    lead_days = rng.integers(0, 31, n_appointments)
    scheduled_dates = appointment_dates - pd.to_timedelta(lead_days, unit="D")
    appt_patient = rng.choice(patient_ids, n_appointments)
    facility_ids = rng.choice([1, 2, 3, 4], n_appointments, p=[0.32, 0.26, 0.22, 0.20])
    sms = rng.binomial(1, 0.58, n_appointments)

    # Previous no-shows are calculated in chronological order, using earlier appointments only.
    order = np.argsort(appointment_dates.values)
    previous_no_shows = np.zeros(n_appointments, dtype=int)
    history: dict[int, int] = {}
    no_show = np.zeros(n_appointments, dtype=object)
    for idx in order:
        pid = int(appt_patient[idx])
        previous_no_shows[idx] = history.get(pid, 0)
        logit = -2.05 + 0.052 * float(lead_days[idx]) + 0.78 * previous_no_shows[idx] - 0.36 * int(sms[idx])
        probability = 1 / (1 + np.exp(-logit))
        missed = bool(rng.random() < probability)
        no_show[idx] = "Yes" if missed else "No"
        history[pid] = history.get(pid, 0) + int(missed)

    appointments = pd.DataFrame({
        "appointment_id": np.arange(500001, 500001 + n_appointments),
        "patient_id": appt_patient,
        "facility_id": facility_ids,
        "scheduled_date": scheduled_dates.strftime("%Y-%m-%d %H:%M:%S"),
        "appointment_date": appointment_dates.strftime("%Y-%m-%d %H:%M:%S"),
        "sms_received": sms,
        "previous_no_shows": previous_no_shows,
        "no_show": no_show,
    })

    attended = appointments.loc[appointments["no_show"].eq("No")].copy()
    visit_rows = []
    for row in attended.itertuples(index=False):
        appt_dt = pd.Timestamp(row.appointment_date)
        facility_pressure = {1: 5, 2: 8, 3: 11, 4: 7}[int(row.facility_id)]
        peak_pressure = 5 if 10 <= appt_dt.hour <= 12 else 0
        weekday_pressure = 3 if appt_dt.dayofweek in (0, 1) else 0
        wait = float(np.clip(rng.normal(9 + facility_pressure + peak_pressure + weekday_pressure, 7), 2, 100))
        arrival_delay = int(rng.integers(0, 31))
        arrival = appt_dt + pd.Timedelta(minutes=arrival_delay)
        service_start = arrival + pd.Timedelta(minutes=wait)
        consultation = float(np.clip(rng.normal(16, 5), 5, 45))
        visit_rows.append({
            "visit_id": len(visit_rows) + 700001,
            "appointment_id": int(row.appointment_id),
            "arrival_time": arrival.strftime("%Y-%m-%d %H:%M:%S"),
            "service_start_time": service_start.strftime("%Y-%m-%d %H:%M:%S"),
            "waiting_minutes": round(wait, 2),
            "consultation_minutes": round(consultation, 2),
        })
    visits = pd.DataFrame(visit_rows)

    medical_rows = []
    for row in visits.itertuples(index=False):
        appt = appointments.loc[appointments["appointment_id"].eq(row.appointment_id)].iloc[0]
        age = int(patients.loc[patients["patient_id"].eq(appt["patient_id"]), "age"].iloc[0])
        medical_rows.append({
            "record_id": len(medical_rows) + 900001,
            "visit_id": int(row.visit_id),
            "systolic_bp": round(float(rng.normal(116 + 0.16 * age, 13)), 1),
            "diastolic_bp": round(float(rng.normal(75 + 0.05 * age, 8)), 1),
            "heart_rate": round(float(rng.normal(78, 11)), 1),
            "temperature_c": round(float(rng.normal(36.8, 0.35)), 2),
            "glucose_mg_dl": round(float(rng.normal(103, 19)), 1),
        })
    medical_records = pd.DataFrame(medical_rows)

    medications = pd.DataFrame({
        "medication_id": np.arange(1, 13),
        "medication_name": ["Paracetamol", "Amoxicillin", "Oral Rehydration Salts", "Ibuprofen", "Metformin", "Amlodipine", "Iron Tablets", "Salbutamol", "Omeprazole", "Cetirizine", "Vitamin D", "Zinc Tablets"],
        "category": ["Analgesic", "Antibiotic", "Rehydration", "Analgesic", "Chronic Care", "Chronic Care", "Supplement", "Respiratory", "Gastrointestinal", "Allergy", "Supplement", "Supplement"],
        "unit": ["tablet", "capsule", "sachet", "tablet", "tablet", "tablet", "tablet", "inhaler", "capsule", "tablet", "capsule", "tablet"],
    })

    # Weekly dispensing demand is used later for a simple one-week-ahead forecasting exercise.
    transaction_rows = []
    tx_id = 300001
    med_base = rng.integers(22, 95, len(medications))
    for med_idx, med in medications.iterrows():
        for week in range(52):
            week_start = pd.Timestamp("2025-01-06") + pd.Timedelta(weeks=week)
            seasonal = 1.0 + 0.13 * np.sin(2 * np.pi * week / 52)
            trend = 1.0 + 0.0015 * week
            demand = max(1, int(rng.poisson(med_base[med_idx] * seasonal * trend)))
            pieces = int(rng.integers(1, 4))
            split = rng.multinomial(demand, np.repeat(1 / pieces, pieces))
            for piece in split:
                if piece <= 0:
                    continue
                tx_date = week_start + pd.Timedelta(days=int(rng.integers(0, 7)))
                transaction_rows.append({
                    "transaction_id": tx_id, "medication_id": int(med.medication_id),
                    "facility_id": int(rng.choice([1, 2, 3, 4])),
                    "transaction_date": tx_date.strftime("%Y-%m-%d"),
                    "transaction_type": "dispense", "quantity": int(piece),
                })
                tx_id += 1
            if week % int(rng.integers(3, 6)) == 0 or week == 0:
                tx_date = week_start + pd.Timedelta(days=int(rng.integers(0, 3)))
                transaction_rows.append({
                    "transaction_id": tx_id, "medication_id": int(med.medication_id),
                    "facility_id": int(rng.choice([1, 2, 3, 4])),
                    "transaction_date": tx_date.strftime("%Y-%m-%d"),
                    "transaction_type": "restock", "quantity": int(demand * rng.uniform(1.2, 2.5)),
                })
                tx_id += 1
    inventory_transactions = pd.DataFrame(transaction_rows)

    # Add data-quality issues to the raw datasets. These are intentional and documented.
    def inject_missing(frame: pd.DataFrame, column: str, fraction: float) -> None:
        if len(frame) == 0:
            return
        idx = rng.choice(frame.index.to_numpy(), size=max(1, int(len(frame) * fraction)), replace=False)
        frame.loc[idx, column] = np.nan

    inject_missing(patients, "age", 0.035)
    inject_missing(patients, "gender", 0.025)
    inject_missing(patients, "neighborhood", 0.045)
    patients.loc[rng.choice(patients.index, size=max(2, int(n_patients * 0.004)), replace=False), "age"] = rng.choice([-8, 125, 180], size=max(2, int(n_patients * 0.004)))
    patients = pd.concat([patients, patients.sample(frac=0.008, random_state=seed)], ignore_index=True)

    inject_missing(appointments, "sms_received", 0.04)
    inject_missing(appointments, "no_show", 0.003)
    appointments = pd.concat([appointments, appointments.sample(frac=0.006, random_state=seed + 1)], ignore_index=True)
    bad_n = max(3, int(n_appointments * 0.002))
    bad_idx = rng.choice(appointments.index[:n_appointments], size=bad_n, replace=False)
    appointments.loc[bad_idx, "appointment_date"] = (
        pd.to_datetime(appointments.loc[bad_idx, "scheduled_date"]) - pd.to_timedelta(2, unit="D")
    ).dt.strftime("%Y-%m-%d %H:%M:%S").values

    inject_missing(visits, "waiting_minutes", 0.035)
    inject_missing(visits, "consultation_minutes", 0.02)
    if len(visits):
        bad_idx = rng.choice(visits.index, size=max(2, int(len(visits) * 0.004)), replace=False)
        visits.loc[bad_idx[:len(bad_idx)//2], "waiting_minutes"] = -15
        visits.loc[bad_idx[len(bad_idx)//2:], "waiting_minutes"] = 420
        visits = pd.concat([visits, visits.sample(frac=0.004, random_state=seed + 2)], ignore_index=True)

    for col, frac in [("systolic_bp", 0.035), ("diastolic_bp", 0.035), ("heart_rate", 0.025), ("temperature_c", 0.02), ("glucose_mg_dl", 0.03)]:
        inject_missing(medical_records, col, frac)
    if len(medical_records):
        ix = rng.choice(medical_records.index, size=max(3, int(len(medical_records) * 0.003)), replace=False)
        medical_records.loc[ix[:2], "systolic_bp"] = [285, 20]
        medical_records.loc[ix[2:], "temperature_c"] = 55
        medical_records = pd.concat([medical_records, medical_records.sample(frac=0.004, random_state=seed + 3)], ignore_index=True)

    inject_missing(inventory_transactions, "quantity", 0.012)
    if len(inventory_transactions):
        ix = rng.choice(inventory_transactions.index, size=max(2, int(len(inventory_transactions) * 0.003)), replace=False)
        inventory_transactions.loc[ix, "quantity"] = -5
        inventory_transactions = pd.concat([inventory_transactions, inventory_transactions.sample(frac=0.005, random_state=seed + 4)], ignore_index=True)

    datasets = {
        "facilities": facilities,
        "patients": patients,
        "appointments": appointments,
        "visits": visits,
        "medical_records": medical_records,
        "medications": medications,
        "inventory_transactions": inventory_transactions,
    }
    for name, frame in datasets.items():
        _write(frame, output_dir, name)
    return {name: int(len(frame)) for name, frame in datasets.items()}
