"""Run the full project workflow."""
from __future__ import annotations
from pathlib import Path
import json
from .config import (RAW_DIR, PROCESSED_DIR, SQL_DIR, REPORTS_DIR, FIGURES_DIR,
                     TABLES_DIR, ARTIFACTS_DIR, DB_PATH, RANDOM_SEED)
from .data_generation import generate_all
from .cleaning import clean_all
from .database import load_clean_data, get_table_counts
from .analysis import run_analysis
from .modeling import run_models


def run_generate() -> dict:
    return generate_all(RAW_DIR, seed=RANDOM_SEED)


def run_clean():
    return clean_all(RAW_DIR, PROCESSED_DIR, TABLES_DIR)


def run_load_db():
    return load_clean_data(PROCESSED_DIR, DB_PATH, SQL_DIR / "schema.sql")


def run_analyze():
    return run_analysis(DB_PATH, FIGURES_DIR, TABLES_DIR)


def run_train():
    return run_models(DB_PATH, ARTIFACTS_DIR, TABLES_DIR, FIGURES_DIR)


def run_all() -> dict:
    generated = run_generate()
    quality = run_clean()
    loaded = run_load_db()
    summaries = run_analyze()
    metrics = run_train()
    summary = {
        "project": "Patient Data Analyzer 2.0",
        "synthetic_data": True,
        "random_seed": RANDOM_SEED,
        "generated_rows": generated,
        "loaded_rows": loaded,
        "cleaning_quality": quality.to_dict(orient="records"),
        "database_counts": get_table_counts(DB_PATH),
        "model_metrics": metrics,
        "note": "All data are synthetic. Model scores describe only this simulation.",
    }
    (REPORTS_DIR / "run_summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    (REPORTS_DIR / "RUN_SUMMARY.md").write_text(_summary_markdown(summary), encoding="utf-8")
    return summary


def _summary_markdown(summary: dict) -> str:
    lines = ["# Pipeline Run Summary", "", "All records in this project are synthetic.", "", "## Database row counts", "", "| Table | Rows |", "|---|---:|"]
    for name, count in summary["database_counts"].items():
        lines.append(f"| {name} | {count:,} |")
    lines += ["", "## Model results", "", "| Task | Main test metric | Value |", "|---|---|---:|"]
    m = summary["model_metrics"]
    lines.append(f"| No-show classification | F1 | {m['no_show_classification']['f1']:.3f} |")
    lines.append(f"| Waiting-time regression | MAE (minutes) | {m['waiting_time_regression']['mae_minutes']:.2f} |")
    lines.append(f"| Weekly medicine forecasting | MAE (units) | {m['weekly_medicine_demand_forecasting']['mae_units']:.2f} |")
    lines += ["", "Clustering and anomaly detection outputs are available in `reports/tables/`. These are exploratory outputs, not clinical conclusions.", ""]
    return "\n".join(lines)
