from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
SQL_DIR = ROOT_DIR / "sql"
REPORTS_DIR = ROOT_DIR / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
TABLES_DIR = REPORTS_DIR / "tables"
ARTIFACTS_DIR = ROOT_DIR / "artifacts"
DB_PATH = ARTIFACTS_DIR / "patient_data_analyzer.db"
RANDOM_SEED = 42

for directory in (RAW_DIR, PROCESSED_DIR, FIGURES_DIR, TABLES_DIR, ARTIFACTS_DIR):
    directory.mkdir(parents=True, exist_ok=True)
