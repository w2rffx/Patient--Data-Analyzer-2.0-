"""Command-line entry point."""
import argparse
from . import pipeline


def main():
    parser = argparse.ArgumentParser(description="Patient Data Analyzer 2.0")
    parser.add_argument("command", choices=["generate", "clean", "load-db", "analyze", "train", "run-all"])
    args = parser.parse_args()
    actions = {
        "generate": pipeline.run_generate,
        "clean": pipeline.run_clean,
        "load-db": pipeline.run_load_db,
        "analyze": pipeline.run_analyze,
        "train": pipeline.run_train,
        "run-all": pipeline.run_all,
    }
    result = actions[args.command]()
    print(f"Completed: {args.command}")
    if args.command == "run-all":
        print("Database counts:", result["database_counts"])
        print("Outputs: reports/ and artifacts/")


if __name__ == "__main__":
    main()
