"""Learning examples for classification, regression, clustering, anomaly detection, and forecasting."""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import pandas as pd
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.cluster import KMeans
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, mean_absolute_error, mean_squared_error, r2_score,
                             silhouette_score)
from sklearn.model_selection import train_test_split
from .database import query_to_dataframe

SEED = 42


def _save_json(payload: dict, path: Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def run_models(db_path: Path, artifacts_dir: Path, tables_dir: Path, figures_dir: Path) -> dict:
    artifacts_dir, tables_dir, figures_dir = map(Path, (artifacts_dir, tables_dir, figures_dir))
    for folder in (artifacts_dir, tables_dir, figures_dir):
        folder.mkdir(parents=True, exist_ok=True)
    results: dict[str, dict] = {}

    # 1. Classification: predict whether a booked appointment will be missed.
    appointments = query_to_dataframe(db_path, """
        SELECT a.appointment_id, a.facility_id, p.age, p.gender, a.lead_days,
               a.appointment_hour, a.appointment_weekday, a.sms_received,
               a.previous_no_shows, a.no_show
        FROM appointments a JOIN patients p USING(patient_id)
        ORDER BY a.appointment_date
    """)
    features = ["facility_id", "age", "gender", "lead_days", "appointment_hour",
                "appointment_weekday", "sms_received", "previous_no_shows"]
    X, y = appointments[features], appointments["no_show"].map({"No": 0, "Yes": 1})
    split = int(len(appointments) * 0.80)
    X_train, X_test = X.iloc[:split], X.iloc[split:]
    y_train, y_test = y.iloc[:split], y.iloc[split:]
    cat = ["gender"]
    num = [c for c in features if c not in cat]
    prep = ColumnTransformer([
        ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), num),
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat),
    ])
    classifier = Pipeline([("prep", prep), ("model", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=SEED))])
    classifier.fit(X_train, y_train)
    pred = classifier.predict(X_test)
    prob = classifier.predict_proba(X_test)[:, 1]
    results["no_show_classification"] = {
        "task": "Binary classification",
        "test_rows": int(len(y_test)),
        "accuracy": float(accuracy_score(y_test, pred)),
        "precision": float(precision_score(y_test, pred, zero_division=0)),
        "recall": float(recall_score(y_test, pred, zero_division=0)),
        "f1": float(f1_score(y_test, pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, prob)) if y_test.nunique() == 2 else None,
        "split": "Chronological 80/20 split by appointment date",
    }
    joblib.dump(classifier, artifacts_dir / "no_show_logistic_regression.joblib")
    pd.DataFrame({"actual": y_test.to_numpy(), "predicted": pred, "probability_no_show": prob}).to_csv(tables_dir / "no_show_test_predictions.csv", index=False)

    # 2. Regression: estimate waiting time using information available from the booking.
    waits = query_to_dataframe(db_path, """
        SELECT v.waiting_minutes, a.facility_id, p.age, a.lead_days,
               a.appointment_hour, a.appointment_weekday
        FROM visits v JOIN appointments a USING(appointment_id)
        JOIN patients p USING(patient_id)
        ORDER BY a.appointment_date
    """)
    reg_features = ["facility_id", "age", "lead_days", "appointment_hour", "appointment_weekday"]
    cut = int(len(waits) * 0.80)
    X_train, X_test = waits[reg_features].iloc[:cut], waits[reg_features].iloc[cut:]
    y_train, y_test = waits["waiting_minutes"].iloc[:cut], waits["waiting_minutes"].iloc[cut:]
    reg = Pipeline([("imputer", SimpleImputer(strategy="median")),
                    ("model", RandomForestRegressor(n_estimators=140, min_samples_leaf=3, random_state=SEED, n_jobs=-1))])
    reg.fit(X_train, y_train)
    pred_wait = reg.predict(X_test)
    rmse = float(np.sqrt(mean_squared_error(y_test, pred_wait)))
    results["waiting_time_regression"] = {
        "task": "Regression",
        "test_rows": int(len(y_test)),
        "mae_minutes": float(mean_absolute_error(y_test, pred_wait)),
        "rmse_minutes": rmse,
        "r2": float(r2_score(y_test, pred_wait)),
        "split": "Chronological 80/20 split by appointment date",
    }
    joblib.dump(reg, artifacts_dir / "waiting_time_random_forest.joblib")
    pd.DataFrame({"actual_wait_minutes": y_test.to_numpy(), "predicted_wait_minutes": pred_wait}).to_csv(tables_dir / "waiting_time_predictions.csv", index=False)

    # 3. Clustering: group patients by appointment behaviour, not by medical condition.
    patients = query_to_dataframe(db_path, """
        SELECT p.patient_id, p.age, COUNT(a.appointment_id) AS appointment_count,
          COALESCE(AVG(CASE WHEN a.no_show='Yes' THEN 1.0 ELSE 0.0 END), 0) AS no_show_rate,
          COALESCE(AVG(a.lead_days), 0) AS mean_lead_days
        FROM patients p LEFT JOIN appointments a USING(patient_id)
        GROUP BY p.patient_id, p.age
    """)
    cluster_cols = ["age", "appointment_count", "no_show_rate", "mean_lead_days"]
    scaled = StandardScaler().fit_transform(patients[cluster_cols])
    kmeans = KMeans(n_clusters=4, random_state=SEED, n_init=10)
    patients["cluster"] = kmeans.fit_predict(scaled)
    sil = float(silhouette_score(scaled, patients["cluster"])) if patients["cluster"].nunique() > 1 else None
    results["patient_behavior_clustering"] = {
        "task": "Unsupervised clustering",
        "patients": int(len(patients)),
        "clusters": 4,
        "silhouette_score": sil,
        "features": cluster_cols,
        "interpretation": "Exploratory groups based on appointment behaviour; not clinical categories.",
    }
    patients.to_csv(tables_dir / "patient_behavior_clusters.csv", index=False)
    joblib.dump({"scaler": StandardScaler().fit(patients[cluster_cols]), "kmeans": kmeans}, artifacts_dir / "patient_behavior_kmeans.joblib")

    # 4. Anomaly detection: find unusual operational visit records for review.
    visits = query_to_dataframe(db_path, """
        SELECT v.visit_id, v.waiting_minutes, v.consultation_minutes,
               a.appointment_hour, a.appointment_weekday, a.facility_id
        FROM visits v JOIN appointments a USING(appointment_id)
    """)
    anomaly_features = ["waiting_minutes", "consultation_minutes", "appointment_hour", "appointment_weekday", "facility_id"]
    iso = IsolationForest(contamination=0.03, random_state=SEED)
    visits["anomaly_flag"] = (iso.fit_predict(visits[anomaly_features]) == -1).astype(int)
    anomaly_rate = float(visits["anomaly_flag"].mean())
    results["operational_anomaly_detection"] = {
        "task": "Unsupervised anomaly detection",
        "visit_rows": int(len(visits)),
        "flagged_rows": int(visits["anomaly_flag"].sum()),
        "flagged_percent": round(anomaly_rate * 100, 2),
        "interpretation": "Flags unusual operational patterns in this dataset; a flag is not proof of an error.",
    }
    visits.loc[visits["anomaly_flag"].eq(1)].to_csv(tables_dir / "unusual_visit_records.csv", index=False)
    joblib.dump(iso, artifacts_dir / "operational_isolation_forest.joblib")

    # 5. Forecasting: estimate one-week-ahead dispensed quantity by medicine.
    tx = query_to_dataframe(db_path, """
        SELECT medication_id, transaction_date, quantity, transaction_type
        FROM inventory_transactions
        WHERE transaction_type='dispense'
        ORDER BY transaction_date
    """)
    tx["transaction_date"] = pd.to_datetime(tx["transaction_date"])
    tx["week_start"] = tx["transaction_date"].dt.to_period("W-SUN").dt.start_time
    weekly = tx.groupby(["medication_id", "week_start"], as_index=False)["quantity"].sum()
    meds = sorted(weekly["medication_id"].unique())
    weeks = pd.date_range(weekly["week_start"].min(), weekly["week_start"].max(), freq="W-MON")
    full = pd.MultiIndex.from_product([meds, weeks], names=["medication_id", "week_start"]).to_frame(index=False)
    weekly = full.merge(weekly, on=["medication_id", "week_start"], how="left").fillna({"quantity": 0})
    weekly = weekly.sort_values(["medication_id", "week_start"]).copy()
    weekly["week_number"] = weekly["week_start"].dt.isocalendar().week.astype(int)
    weekly["time_index"] = weekly.groupby("medication_id").cumcount()
    grouped = weekly.groupby("medication_id")["quantity"]
    weekly["lag_1"] = grouped.shift(1)
    weekly["lag_2"] = grouped.shift(2)
    weekly["lag_4"] = grouped.shift(4)
    weekly["rolling_mean_4"] = grouped.transform(lambda s: s.shift(1).rolling(4, min_periods=4).mean())
    model_data = weekly.dropna(subset=["lag_1", "lag_2", "lag_4", "rolling_mean_4"]).copy()
    last_train_week = weeks[int(len(weeks) * 0.80) - 1]
    train = model_data.loc[model_data["week_start"] <= last_train_week]
    test = model_data.loc[model_data["week_start"] > last_train_week]
    forecast_features = ["medication_id", "week_number", "time_index", "lag_1", "lag_2", "lag_4", "rolling_mean_4"]
    forecaster = RandomForestRegressor(n_estimators=160, min_samples_leaf=2, random_state=SEED, n_jobs=-1)
    forecaster.fit(train[forecast_features], train["quantity"])
    pred_demand = np.maximum(0, forecaster.predict(test[forecast_features]))
    results["weekly_medicine_demand_forecasting"] = {
        "task": "One-step-ahead weekly demand regression",
        "test_rows": int(len(test)),
        "mae_units": float(mean_absolute_error(test["quantity"], pred_demand)),
        "rmse_units": float(np.sqrt(mean_squared_error(test["quantity"], pred_demand))),
        "r2": float(r2_score(test["quantity"], pred_demand)),
        "split": "Chronological split; lag features use earlier weeks only.",
    }
    forecast_out = test[["medication_id", "week_start", "quantity"]].copy()
    forecast_out["predicted_quantity"] = pred_demand
    forecast_out.to_csv(tables_dir / "medicine_demand_forecasts.csv", index=False)
    joblib.dump(forecaster, artifacts_dir / "medicine_demand_random_forest.joblib")

    _save_json(results, tables_dir / "model_metrics.json")
    # Compact metric chart. Values remain task-specific; no combined ranking is implied.
    labels = ["No-show F1", "Wait MAE (min)", "Medicine MAE (units)"]
    values = [results["no_show_classification"]["f1"],
              results["waiting_time_regression"]["mae_minutes"],
              results["weekly_medicine_demand_forecasting"]["mae_units"]]
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.bar(labels, values)
    ax.set_title("Selected Model Metrics (Different Units - Do Not Compare Directly)")
    ax.set_ylabel("Metric value")
    ax.tick_params(axis="x", rotation=12)
    fig.tight_layout()
    fig.savefig(figures_dir / "model_metrics.png", dpi=180)
    plt.close(fig)
    return results
