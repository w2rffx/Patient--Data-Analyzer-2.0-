"""Patient Data Analyzer 2.0."""

__version__ = "2.0.0"
