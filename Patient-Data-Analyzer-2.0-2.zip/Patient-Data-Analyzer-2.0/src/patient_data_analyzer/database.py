"""SQLite database setup and data loading."""
from __future__ import annotations
from pathlib import Path
import sqlite3
import pandas as pd

TABLE_ORDER = [
    "facilities", "patients", "medications", "appointments",
    "visits", "medical_records", "inventory_transactions"
]


def connect(db_path: Path) -> sqlite3.Connection:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(db_path)
    connection.execute("PRAGMA foreign_keys = ON")
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database(db_path: Path, schema_path: Path) -> None:
    schema = Path(schema_path).read_text(encoding="utf-8")
    with connect(db_path) as conn:
        conn.executescript(schema)


def load_clean_data(processed_dir: Path, db_path: Path, schema_path: Path) -> dict[str, int]:
    """Load clean CSV tables into SQLite in foreign-key order."""
    initialize_database(db_path, schema_path)
    loaded = {}
    with connect(db_path) as conn:
        # Clear child tables first so rerunning the loader is safe.
        for table in reversed(TABLE_ORDER):
            conn.execute(f"DELETE FROM {table}")
        for table in TABLE_ORDER:
            csv_path = Path(processed_dir) / f"{table}.csv"
            if not csv_path.exists():
                raise FileNotFoundError(f"Clean file not found: {csv_path}. Run cleaning first.")
            frame = pd.read_csv(csv_path)
            frame.to_sql(table, conn, if_exists="append", index=False)
            loaded[table] = int(len(frame))
        conn.commit()
    return loaded


def query_to_dataframe(db_path: Path, query: str, params: tuple | None = None) -> pd.DataFrame:
    with connect(db_path) as conn:
        return pd.read_sql_query(query, conn, params=params)


def get_table_counts(db_path: Path) -> dict[str, int]:
    counts = {}
    with connect(db_path) as conn:
        for table in TABLE_ORDER:
            counts[table] = int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
    return counts
