from pathlib import Path
import pandas as pd
from patient_data_analyzer.data_generation import generate_all
from patient_data_analyzer.cleaning import clean_all
from patient_data_analyzer.database import load_clean_data, get_table_counts, query_to_dataframe


def test_small_end_to_end_data_and_database(tmp_path: Path):
    raw = tmp_path / "raw"
    processed = tmp_path / "processed"
    reports = tmp_path / "reports"
    sql_dir = Path(__file__).resolve().parents[1] / "sql"
    db = tmp_path / "test.db"

    generated = generate_all(raw, seed=7, n_patients=100, n_appointments=450)
    assert generated["patients"] >= 100
    quality = clean_all(raw, processed, reports)
    assert (reports / "data_quality_summary.csv").exists()
    assert quality["missing_cells_after"].sum() == 0

    load_clean_data(processed, db, sql_dir / "schema.sql")
    counts = get_table_counts(db)
    assert counts["patients"] > 0
    assert counts["appointments"] > 0
    assert counts["visits"] > 0

    fk_check = query_to_dataframe(db, "PRAGMA foreign_key_check")
    assert fk_check.empty


def test_cleaning_keeps_age_in_expected_range(tmp_path: Path):
    raw = tmp_path / "raw"
    processed = tmp_path / "processed"
    reports = tmp_path / "reports"
    generate_all(raw, seed=11, n_patients=80, n_appointments=300)
    clean_all(raw, processed, reports)
    patients = pd.read_csv(processed / "patients.csv")
    assert patients["age"].between(1, 110).all()
    assert patients["patient_id"].is_unique
